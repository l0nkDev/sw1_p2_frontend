package com.example.flutter_generated

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
